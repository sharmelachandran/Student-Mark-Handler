package com.example.evernote;

import android.app.Application;

public class Evernote extends Application {
}
