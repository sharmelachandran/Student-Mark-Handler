package com.example.evernote;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class download extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_download);
    }
}
